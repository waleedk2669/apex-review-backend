const express = require("express");
const env = require("dotenv");
const checkoutRoutes = require("./routes/checkoutRoutes");
const cors = require("cors");

require("dotenv").config({
  path: `./.env`,
});

const app = express();
app.use(cors());
app.use(express.static("public"));
app.use(express.json()); // Middleware to parse JSON bodies

app.use("/api/checkout", checkoutRoutes);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Running on port ${PORT}`));
